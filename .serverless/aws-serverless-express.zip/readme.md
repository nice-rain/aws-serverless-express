# AWS Serverless Express Example
This is a simple example of an express GET that returns Hello World that can be run in a serverless environment.